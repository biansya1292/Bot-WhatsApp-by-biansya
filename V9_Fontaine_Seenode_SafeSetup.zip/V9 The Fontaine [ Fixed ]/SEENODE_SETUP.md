# V9 The Fontaine — Seenode setup (safer preparation)

## Important
- This is a community Baileys/WhatsApp Web bot, not the official WhatsApp Business API. Use only an account you control and comply with WhatsApp terms.
- The original startup file was obfuscated and attempted to message a hard-coded number, automatically join hard-coded groups, and follow hard-coded channels. Those startup actions were removed. Runtime testing is still required.
- API-like values in settings.js were blanked because the archive contained credential-looking values. Revoke/rotate the originals with their providers if they were real.
- The project uses many older/third-party dependencies. A successful install does not guarantee every command or API still works.

## Seenode steps
1. Extract the ZIP and upload the *contents* of `V9 The Fontaine [ Fixed ]/` to the app's project/root directory. Avoid uploading it as an extra nested folder.
2. Choose a Node.js runtime from 18 through 22 if available.
3. Install command: `npm install`. Read any install/build errors rather than ignoring them.
4. Start command: `npm start` (runs `node index.js`).
5. Enable persistent storage/volume if your plan supports it. The `session` directory contains WhatsApp authentication and must persist across restarts. Never share or publish it.
6. Watch the console. The bot asks for the WhatsApp number and generates a pairing code. Enter the number in international digits format when prompted, then enter the code in WhatsApp > Linked devices > Link with phone number. Do not share the code. If the host does not support interactive console input, this pairing flow may need adaptation.
7. After pairing, restart once and verify that the bot reconnects without asking to pair again.

## Configuration and safety
- Edit `settings.js` to set your own bot name and owner number. Several owner-number globals are duplicated; update matching entries consistently.
- Re-enter only API keys you own and actually need. Prefer Seenode's environment/secrets settings instead of hard-coding keys. Do not restore the old panel API keys.
- Keep `session/`, database files, and logs private. Back them up securely.

## Basic checks
- Run `npm run check` to validate syntax of the main JS files. This does not test every feature.
- After startup, test `.menu` and a simple text command in a private chat. Test group commands only in a group you administer.
- If startup fails, inspect the first error in Seenode logs, verify Node version, retry `npm install`, and ensure folders such as `lib/`, `database/`, `data/`, `scrape/` and `module.js` were uploaded.
- Do not assume this old bot is bug-free; third-party APIs, WhatsApp changes, native dependencies, and individual commands may need further fixes.
