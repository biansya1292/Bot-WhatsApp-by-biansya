/**

 SC BOT : FURINA V9 NO ENC
 VERSION : V9 UPDATE
 
 CREATED BY : FALLZX INFINITY
 BASE : DINZBOTZ 
 
 
 NOTE : 
 INI SENGAJA KU ENC , KARNA KEBANYAKAN ORANG PADA MENGAKU² DAN MERENAME TOTAL MENJADI NAMA DIA. HARGAI CREATOR YNG TELAH MEMBUATNYA. 
 
 
 THANKS TO CREATOR FURINA :
 DINZIDCHX 
 RXQZ OFFC
 FALLZX - INFINITY

 CREDIT JANGAN DIHAPUS 
**/
require("./settings");
const {
  modul
} = require("./module");
const {
  baileys,
  boom,
  chalk,
  fs,
  figlet,
  FileType,
  path,
  pino,
  process,
  PhoneNumber,
  axios,
  yargs,
  _
} = modul;
const {
  Boom
} = boom;
const {
  default: XeonBotIncConnect,
  BufferJSON,
  processedMessages,
  PHONENUMBER_MCC,
  initInMemoryKeyStore,
  DisconnectReason,
  AnyMessageContent,
  makeInMemoryStore,
  useMultiFileAuthState,
  delay,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  jidDecode,
  makeCacheableSignalKeyStore,
  getAggregateVotesInPollMessage,
  proto, 
  Browsers
} = require("lily-baileys");
const cfonts = require('cfonts');
const {
  color,
  bgcolor
} = require("./lib/color");
const NodeCache = require("node-cache");
const Pino = require('pino');
const readline = require("readline");
const colors = require("colors");
const {
  start
} = require("./lib/spinner");
const {
  uncache,
  nocache
} = require("./lib/loader");
const {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid
} = require("./lib/exif");
const {
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  await,
  sleep,
  reSize
} = require("./lib/myfunc");
global.db = JSON.parse(fs.readFileSync("./database/database.json"));
if (global.db) {
  global.db = {
    'sticker': {},
    'database': {},
    'groups': {},
    'game': {},
    'others': {},
    'users': {},
    'chats': {},
    'settings': {},
    ...(global.db || {})
  };
}
const pairingCode = true || process.argv.includes("--pairing-code");
const useMobile = process.argv.includes("--mobile");
const store = makeInMemoryStore({
  'logger': pino().child({
    'level': "silent",
    'stream': "store"
  })
});
const rl = readline.createInterface({
  'input': process.stdin,
  'output': process.stdout
});
const question = _0x33991d => new Promise(_0x3facd2 => rl.question(_0x33991d, _0x3facd2));
require("./Furina.js");
nocache('../Furina.js', _0x140c46 => console.log(color("[ CHANGE ]", 'green'), color("'" + _0x140c46 + "'", "green"), "Updated"));
require("./index.js");
nocache("../index.js", _0x5a7631 => console.log(color("[ CHANGE ]", 'green'), color("'" + _0x5a7631 + "'", 'green'), 'Updated'));
async function theFontaine() {
  const {
    saveCreds: _0x1f4935,
    state: _0xadba1b
  } = await useMultiFileAuthState('./' + sessionName);
  const _0x2490f9 = new NodeCache();
  const _0x4dbfb4 = XeonBotIncConnect({
    'logger': pino({
      'level': "silent"
    }),
    'printQRInTerminal': !pairingCode,
    'mobile': useMobile,
    'auth': _0xadba1b, 
    'browser': Browsers.ubuntu("Chrome"),
    'patchMessageBeforeSending': _0x51c8b3 => {
      const _0x205f7e = !!(_0x51c8b3.buttonsMessage || _0x51c8b3.templateMessage || _0x51c8b3.listMessage);
      if (_0x205f7e) {
        _0x51c8b3 = {
          'viewOnceMessage': {
            'message': {
              'messageContextInfo': {
                'deviceListMetadataVersion': 0x2,
                'deviceListMetadata': {}
              },
              ..._0x51c8b3
            }
          }
        };
      }
      return _0x51c8b3;
    },
    'connectTimeoutMs': 0xea60,
    'defaultQueryTimeoutMs': 0x0,
    'keepAliveIntervalMs': 0x2710,
    'emitOwnEvents': true,
    'fireInitQueries': true,
    'generateHighQualityLinkPreview': true,
    'syncFullHistory': true,
    'markOnlineOnConnect': true,
    'getMessage': async _0x24889f => {
      if (store) {
        const _0x41ca97 = await store.loadMessage(_0x24889f.remoteJid, _0x24889f.id);
        return _0x41ca97.message || undefined;
      }
      return {
        'conversation': "Cheems Bot Here!"
      };
    },
    'msgRetryCounterCache': _0x2490f9,
    'defaultQueryTimeoutMs': undefined
  });
  if (!_0x4dbfb4.authState.creds.registered) {
    const _0x53750d = await question("Masukan Nomer Yang Aktif Awali Dengan 62 Recode :\n");
    let _0x3f8fbb = await _0x4dbfb4.requestPairingCode(_0x53750d);
    _0x3f8fbb = _0x3f8fbb?.["match"](/.{1,4}/g)?.["join"]('-') || _0x3f8fbb;
    console.log("𝙽𝙸 𝙺𝙾𝙳𝙴 𝙿𝙰𝙸𝚁𝙸𝙽𝙶 𝙻𝚄 :", _0x3f8fbb);
  }
  store.bind(_0x4dbfb4.ev);
  _0x4dbfb4.ev.on('connection.update', async _0x20fe1f => {
    const {
      connection: _0x357ba3,
      lastDisconnect: _0x2bf518,
      receivedPendingNotifications: _0x1021c7
    } = _0x20fe1f;
    try {
      if (_0x357ba3 === "close") {
        const _0x53d240 = new Boom(_0x2bf518?.["error"])?.["output"]?.['statusCode'] || 'Unknown';
        console.log("🔴 Disconnect detected. Reason: " + _0x53d240);
        switch (_0x53d240) {
          case DisconnectReason.badSession:
            console.log("⚠️ Bad Session File. Please delete the session and scan again.");
            break;
          case DisconnectReason.connectionClosed:
            console.log("🔄 Connection closed, reconnecting...");
            break;
          case DisconnectReason.connectionLost:
            console.log("📡 Connection lost from server, reconnecting...");
            break;
          case DisconnectReason.connectionReplaced:
            console.log("⚠️ Connection replaced. Please close the previous session.");
            break;
          case DisconnectReason.loggedOut:
            console.log("🚫 Logged out. Scan again to login.");
            break;
          case DisconnectReason.restartRequired:
            console.log("🔁 Restart required. Restarting...");
            break;
          case DisconnectReason.timedOut:
            console.log("⏱️ Connection timed out. Reconnecting...");
            break;
          default:
            console.log("❓ Unknown disconnect reason: " + _0x53d240);
            break;
        }
        await delay(0xbb8);
        theFontaine();
      }
      if (_0x357ba3 === "connecting") {
        console.log("🟡 Connecting to WhatsApp...");
      }
      if (_0x357ba3 === "open") {
        await delay(0x7d0);
        try {         
const teksnotif = `🌸 ʜᴀʟᴏ ᴏᴡɴᴇʀ...

✨ ꜱᴄ ᴛᴇʟᴀʜ ᴀᴋᴛɪꜰ 💫
💠 ᴀɴᴛɪ ʙᴀᴄᴋᴅᴏʀ — ʙᴇʙᴀꜱ ᴇʀʀᴏʀ
🆔 ʙᴏᴛ ɪᴅ: ${_0x4dbfb4.user.id.split(":")[0]}`

console.log('🟢 Bot is connected and running.')
// Removed: unsolicited notification to a hard-coded external number.
// Removed: automatic joining of hard-coded WhatsApp groups.

        } catch (_) {}
        cfonts.say("Furina", {
          'font': "block",
          'align': "left",
          'colors': ["blue", "blueBright"],
          'background': 'transparent',
          'maxLength': 0x14,
          'rawMode': false
        });
        console.log("🟢 Bot is connected and running.");
        // Removed: automatic following of hard-coded WhatsApp channels.

      }
    } catch (_0x49cd7b) {
      console.error("❌ Error in connection update:", _0x49cd7b);
      await delay(0xbb8);
      theFontaine();
    }
  });
  await delay(0x15b3);
  start('2', colors.bold.white("\n\nMenunggu Pesan Baru.."));
  _0x4dbfb4.ev.on("creds.update", await _0x1f4935);
  _0x4dbfb4.ev.on('call', async _0x215754 => {
    let _0x53c40e = await _0x4dbfb4.decodeJid(_0x4dbfb4.user.id);
    let _0x2b79c3 = db.settings[_0x53c40e].anticall;
    if (!_0x2b79c3) {
      return;
    }
    console.log(_0x215754);
    for (let _0x5ca194 of _0x215754) {
      if (_0x5ca194.isGroup == false) {
        if (_0x5ca194.status == "offer") {
          let _0x16409f = await _0x4dbfb4.sendTextWithMentions(_0x5ca194.from, '*' + _0x4dbfb4.user.name + "* can't receive " + (_0x5ca194.isVideo ? 'video' : "voice") + " call. Sorry @" + _0x5ca194.from.split('@')[0x0] + " you will be blocked. If accidentally please contact the owner to be unblocked !");
          _0x4dbfb4.sendContact(_0x5ca194.from, global.owner, _0x16409f);
          await sleep(0x1f40);
          await _0x4dbfb4.updateBlockStatus(_0x5ca194.from, "block");
        }
      }
    }
  });
  _0x4dbfb4.ev.on("messages.upsert", async _0x5bea83 => {
    try {
      const _0x370247 = _0x5bea83.messages[0x0];
      if (!_0x370247.message) {
        return;
      }
      _0x370247.message = Object.keys(_0x370247.message)[0x0] === "ephemeralMessage" ? _0x370247.message.ephemeralMessage.message : _0x370247.message;
      if (_0x370247.key && _0x370247.key.remoteJid === "status@broadcast") {
        await _0x4dbfb4.readMessages([_0x370247.key]);
      }
      if (!_0x4dbfb4['public'] && !_0x370247.key.fromMe && _0x5bea83.type === "notify") {
        return;
      }
      if (_0x370247.key.id.startsWith("BAE5") && _0x370247.key.id.length === 0x10) {
        return;
      }
      const _0x3b1910 = smsg(_0x4dbfb4, _0x370247, store);
      require('./Furina')(_0x4dbfb4, _0x3b1910, _0x5bea83, store);
    } catch (_0x15d5f2) {
      console.log(_0x15d5f2);
    }
  });
  async function _0x4964c0(_0x54b64f) {
    if (store) {
      const _0x4f98b7 = await store.loadMessage(_0x54b64f.remoteJid, _0x54b64f.id);
      return _0x4f98b7?.["message"];
    }
    return {
      'conversation': "Dansya Bot Ada Di Sini"
    };
  }
  _0x4dbfb4.ev.on("messages.update", async _0xa873a3 => {
    for (const {
      key: _0x5879fc,
      update: _0x2b6be8
    } of _0xa873a3) {
      if (_0x2b6be8.pollUpdates && !_0x5879fc.fromMe) {
        const _0x39e4dd = await _0x4964c0(_0x5879fc);
        if (_0x39e4dd) {
          const _0x3acc36 = await getAggregateVotesInPollMessage({
            'message': _0x39e4dd,
            'pollUpdates': _0x2b6be8.pollUpdates
          });
          var _0x3e5aee = _0x3acc36.filter(_0xf637cc => _0xf637cc.voters.length !== 0x0)[0x0]?.["name"];
          if (_0x3e5aee == undefined) {
            return;
          }
          var _0x125135 = '' + _0x3e5aee;
          _0x4dbfb4.appenTextMessage(_0x125135, _0xa873a3);
        }
      }
    }
  });
  _0x4dbfb4.sendTextWithMentions = async (_0x145321, _0x347eab, _0x10c605, _0x1a131b = {}) => _0x4dbfb4.sendMessage(_0x145321, {
    'text': _0x347eab,
    'contextInfo': {
      'mentionedJid': [..._0x347eab.matchAll(/@(\d{0,16})/g)].map(_0x3094cd => _0x3094cd[0x1] + "@s.whatsapp.net")
    },
    ..._0x1a131b
  }, {
    'quoted': _0x10c605
  });
  _0x4dbfb4.decodeJid = _0x24e4d0 => {
    if (!_0x24e4d0) {
      return _0x24e4d0;
    }
    if (/:\d+@/gi.test(_0x24e4d0)) {
      let _0x26c20c = jidDecode(_0x24e4d0) || {};
      return _0x26c20c.user && _0x26c20c.server && _0x26c20c.user + '@' + _0x26c20c.server || _0x24e4d0;
    } else {
      return _0x24e4d0;
    }
  };
  _0x4dbfb4.ev.on("contacts.update", _0x5a4498 => {
    for (let _0x4de270 of _0x5a4498) {
      let _0xc0d85 = _0x4dbfb4.decodeJid(_0x4de270.id);
      if (store && store.contacts) {
        store.contacts[_0xc0d85] = {
          'id': _0xc0d85,
          'name': _0x4de270.notify
        };
      }
    }
  });
  _0x4dbfb4.getName = (_0x328eed, _0x12346 = false) => {
    id = _0x4dbfb4.decodeJid(_0x328eed);
    _0x12346 = _0x4dbfb4.withoutContact || _0x12346;
    let _0xfe5164;
    if (id.endsWith('@g.us')) {
      return new Promise(async _0x54ff08 => {
        _0xfe5164 = store.contacts[id] || {};
        if (!(_0xfe5164.name || _0xfe5164.subject)) {
          _0xfe5164 = _0x4dbfb4.groupMetadata(id) || {};
        }
        _0x54ff08(_0xfe5164.name || _0xfe5164.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber("international"));
      });
    } else {
      _0xfe5164 = id === "0@s.whatsapp.net" ? {
        'id': id,
        'name': 'WhatsApp'
      } : id === _0x4dbfb4.decodeJid(_0x4dbfb4.user.id) ? _0x4dbfb4.user : store.contacts[id] || {};
    }
    return (_0x12346 ? '' : _0xfe5164.name) || _0xfe5164.subject || _0xfe5164.verifiedName || PhoneNumber('+' + _0x328eed.replace("@s.whatsapp.net", '')).getNumber("international");
  };
  _0x4dbfb4.parseMention = (_0x207540 = '') => {
    return [..._0x207540.matchAll(/@([0-9]{5,16}|0)/g)].map(_0x4fa927 => _0x4fa927[0x1] + "@s.whatsapp.net");
  };
  _0x4dbfb4.sendContact = async (_0x460e37, _0x37d89d, _0x30b5d0 = '', _0x14ab33 = {}) => {
    let _0x57afb2 = [];
    for (let _0x344e3c of _0x37d89d) {
      _0x57afb2.push({
        'displayName': await _0x4dbfb4.getName(_0x344e3c),
        'vcard': "BEGIN:VCARD\nVERSION:3.0\nN:" + (await _0x4dbfb4.getName(_0x344e3c)) + "\nFN:" + (await _0x4dbfb4.getName(_0x344e3c)) + "\nitem1.TEL;waid=" + _0x344e3c + ':' + _0x344e3c + "\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:" + ytname + "\nitem2.X-ABLabel:YouTube\nitem3.URL:" + socialm + "\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;" + location + ";;;;\nitem4.X-ABLabel:Region\nEND:VCARD"
      });
    }
    _0x4dbfb4.sendMessage(_0x460e37, {
      'contacts': {
        'displayName': _0x57afb2.length + " Contact",
        'contacts': _0x57afb2
      },
      ..._0x14ab33
    }, {
      'quoted': _0x30b5d0
    });
  };
  _0x4dbfb4.setStatus = _0x1d1570 => {
    _0x4dbfb4.query({
      'tag': 'iq',
      'attrs': {
        'to': '@s.whatsapp.net',
        'type': "set",
        'xmlns': 'status'
      },
      'content': [{
        'tag': "status",
        'attrs': {},
        'content': Buffer.from(_0x1d1570, "utf-8")
      }]
    });
    return _0x1d1570;
  };
  _0x4dbfb4["public"] = true;
  _0x4dbfb4.sendImage = async (_0x5f322e, _0x1fce22, _0x3b24f8 = '', _0x3eb80f = '', _0x40609a) => {
    let _0x19fe02 = Buffer.isBuffer(_0x1fce22) ? _0x1fce22 : /^data:.*?\/.*?;base64,/i.test(_0x1fce22) ? Buffer.from(_0x1fce22.split`,`[0x1], 'base64') : /^https?:\/\//.test(_0x1fce22) ? await await getBuffer(_0x1fce22) : fs.existsSync(_0x1fce22) ? fs.readFileSync(_0x1fce22) : Buffer.alloc(0x0);
    return await _0x4dbfb4.sendMessage(_0x5f322e, {
      'image': _0x19fe02,
      'caption': _0x3b24f8,
      ..._0x40609a
    }, {
      'quoted': _0x3eb80f
    });
  };
  _0x4dbfb4.sendImageAsSticker = async (_0xdbee02, _0x23e282, _0x26e720, _0x3a68d2 = {}) => {
    let _0x16ae66 = Buffer.isBuffer(_0x23e282) ? _0x23e282 : /^data:.*?\/.*?;base64,/i.test(_0x23e282) ? Buffer.from(_0x23e282.split`,`[0x1], "base64") : /^https?:\/\//.test(_0x23e282) ? await await getBuffer(_0x23e282) : fs.existsSync(_0x23e282) ? fs.readFileSync(_0x23e282) : Buffer.alloc(0x0);
    let _0x42c8cd;
    if (_0x3a68d2 && (_0x3a68d2.packname || _0x3a68d2.author)) {
      _0x42c8cd = await writeExifImg(_0x16ae66, _0x3a68d2);
    } else {
      _0x42c8cd = await imageToWebp(_0x16ae66);
    }
    await _0x4dbfb4.sendMessage(_0xdbee02, {
      'sticker': {
        'url': _0x42c8cd
      },
      ..._0x3a68d2
    }, {
      'quoted': _0x26e720
    }).then(_0x227c89 => {
      fs.unlinkSync(_0x42c8cd);
      return _0x227c89;
    });
  };
  _0x4dbfb4.sendVideoAsSticker = async (_0x13b60e, _0x124181, _0x5b9c77, _0x2870e9 = {}) => {
    let _0x185ad7 = Buffer.isBuffer(_0x124181) ? _0x124181 : /^data:.*?\/.*?;base64,/i.test(_0x124181) ? Buffer.from(_0x124181.split`,`[0x1], "base64") : /^https?:\/\//.test(_0x124181) ? await await getBuffer(_0x124181) : fs.existsSync(_0x124181) ? fs.readFileSync(_0x124181) : Buffer.alloc(0x0);
    let _0x269e8b;
    if (_0x2870e9 && (_0x2870e9.packname || _0x2870e9.author)) {
      _0x269e8b = await writeExifVid(_0x185ad7, _0x2870e9);
    } else {
      _0x269e8b = await videoToWebp(_0x185ad7);
    }
    await _0x4dbfb4.sendMessage(_0x13b60e, {
      'sticker': {
        'url': _0x269e8b
      },
      ..._0x2870e9
    }, {
      'quoted': _0x5b9c77
    });
    return _0x269e8b;
  };
  _0x4dbfb4.copyNForward = async (_0x77adc5, _0x3ab703, _0x37fab3 = false, _0x3de5c4 = {}) => {
    let _0x17a6f3;
    if (_0x3de5c4.readViewOnce) {
      _0x3ab703.message = _0x3ab703.message && _0x3ab703.message.ephemeralMessage && _0x3ab703.message.ephemeralMessage.message ? _0x3ab703.message.ephemeralMessage.message : _0x3ab703.message || undefined;
      _0x17a6f3 = Object.keys(_0x3ab703.message.viewOnceMessage.message)[0x0];
      delete (_0x3ab703.message && _0x3ab703.message.ignore ? _0x3ab703.message.ignore : _0x3ab703.message || undefined);
      delete _0x3ab703.message.viewOnceMessage.message[_0x17a6f3].viewOnce;
      _0x3ab703.message = {
        ..._0x3ab703.message.viewOnceMessage.message
      };
    }
    let _0x2a1ff6 = Object.keys(_0x3ab703.message)[0x0];
    let _0x1cd06b = await generateForwardMessageContent(_0x3ab703, _0x37fab3);
    let _0x2577f6 = Object.keys(_0x1cd06b)[0x0];
    let _0x549c0f = {};
    if (_0x2a1ff6 != 'conversation') {
      _0x549c0f = _0x3ab703.message[_0x2a1ff6].contextInfo;
    }
    _0x1cd06b[_0x2577f6].contextInfo = {
      ..._0x549c0f,
      ..._0x1cd06b[_0x2577f6].contextInfo
    };
    const _0xc79b07 = await generateWAMessageFromContent(_0x77adc5, _0x1cd06b, _0x3de5c4 ? {
      ..._0x1cd06b[_0x2577f6],
      ..._0x3de5c4,
      ...(_0x3de5c4.contextInfo ? {
        'contextInfo': {
          ..._0x1cd06b[_0x2577f6].contextInfo,
          ..._0x3de5c4.contextInfo
        }
      } : {})
    } : {});
    await _0x4dbfb4.relayMessage(_0x77adc5, _0xc79b07.message, {
      'messageId': _0xc79b07.key.id
    });
    return _0xc79b07;
  };
  _0x4dbfb4.downloadAndSaveMediaMessage = async (_0x3b71d1, _0x1e6802, _0x115ee4 = true) => {
    let _0x946c45 = _0x3b71d1.msg ? _0x3b71d1.msg : _0x3b71d1;
    let _0xa13efa = (_0x3b71d1.msg || _0x3b71d1).mimetype || '';
    let _0x46581b = _0x3b71d1.mtype ? _0x3b71d1.mtype.replace(/Message/gi, '') : _0xa13efa.split('/')[0x0];
    const _0x2a7430 = await downloadContentFromMessage(_0x946c45, _0x46581b);
    let _0x4e76bd = Buffer.from([]);
    for await (const _0x2686e7 of _0x2a7430) {
      _0x4e76bd = Buffer.concat([_0x4e76bd, _0x2686e7]);
    }
    let _0x358dcb = await FileType.fromBuffer(_0x4e76bd);
    trueFileName = _0x115ee4 ? _0x1e6802 + '.' + _0x358dcb.ext : _0x1e6802;
    await fs.writeFileSync(trueFileName, _0x4e76bd);
    return trueFileName;
  };
  _0x4dbfb4.downloadMediaMessage = async _0x7aa1d => {
    let _0x32944c = (_0x7aa1d.msg || _0x7aa1d).mimetype || '';
    let _0x4c8761 = _0x7aa1d.mtype ? _0x7aa1d.mtype.replace(/Message/gi, '') : _0x32944c.split('/')[0x0];
    const _0x3037d5 = await downloadContentFromMessage(_0x7aa1d, _0x4c8761);
    let _0x41a649 = Buffer.from([]);
    for await (const _0x3e8b20 of _0x3037d5) {
      _0x41a649 = Buffer.concat([_0x41a649, _0x3e8b20]);
    }
    return _0x41a649;
  };
  _0x4dbfb4.getFile = async (_0x5706f3, _0x25d81c) => {
    let _0x457b86;
    let _0x3a4992 = Buffer.isBuffer(_0x5706f3) ? _0x5706f3 : /^data:.*?\/.*?;base64,/i.test(_0x5706f3) ? Buffer.from(_0x5706f3.split`,`[0x1], "base64") : /^https?:\/\//.test(_0x5706f3) ? await (_0x457b86 = await getBuffer(_0x5706f3)) : fs.existsSync(_0x5706f3) ? (filename = _0x5706f3, fs.readFileSync(_0x5706f3)) : typeof _0x5706f3 === "string" ? _0x5706f3 : Buffer.alloc(0x0);
    let _0x237221 = (await FileType.fromBuffer(_0x3a4992)) || {
      'mime': "application/octet-stream",
      'ext': ".bin"
    };
    filename = path.join(__filename, "./lib" + new Date() * 0x1 + '.' + _0x237221.ext);
    if (_0x3a4992 && _0x25d81c) {
      fs.promises.writeFile(filename, _0x3a4992);
    }
    return {
      'res': _0x457b86,
      'filename': filename,
      'size': await getSizeMedia(_0x3a4992),
      ..._0x237221,
      'data': _0x3a4992
    };
  };
  _0x4dbfb4.sendMedia = async (_0x346059, _0x4f95c5, _0x131716 = '', _0x4c290c = '', _0x208b6b = '', _0x434bd2 = {}) => {
    let _0x1ee42a = await _0x4dbfb4.getFile(_0x4f95c5, true);
    let {
      mime: _0x3dbd95,
      ext: _0x5b7856,
      res: _0x2031f9,
      data: _0x208b92,
      filename: _0x358b09
    } = _0x1ee42a;
    if (_0x2031f9 && _0x2031f9.status !== 0xc8 || file.length <= 0x10000) {
      try {
        throw {
          'json': JSON.parse(file.toString())
        };
      } catch (_0x22c185) {
        if (_0x22c185.json) {
          throw _0x22c185.json;
        }
      }
    }
    let _0x5e882a = '';
    let _0x1ce4e = _0x3dbd95;
    let _0x37f972 = _0x358b09;
    if (_0x434bd2.asDocument) {
      _0x5e882a = "document";
    }
    if (_0x434bd2.asSticker || /webp/.test(_0x3dbd95)) {
      let {
        writeExif: _0x55b15b
      } = require('./lib/exif');
      let _0x3571ef = {
        'mimetype': _0x3dbd95,
        'data': _0x208b92
      };
      _0x37f972 = await _0x55b15b(_0x3571ef, {
        'packname': _0x434bd2.packname ? _0x434bd2.packname : global.packname,
        'author': _0x434bd2.author ? _0x434bd2.author : global.author,
        'categories': _0x434bd2.categories ? _0x434bd2.categories : []
      });
      await fs.promises.unlink(_0x358b09);
      _0x5e882a = "sticker";
      _0x1ce4e = 'image/webp';
    } else {
      if (/image/.test(_0x3dbd95)) {
        _0x5e882a = "image";
      } else {
        if (/video/.test(_0x3dbd95)) {
          _0x5e882a = "video";
        } else {
          if (/audio/.test(_0x3dbd95)) {
            _0x5e882a = "audio";
          } else {
            _0x5e882a = "document";
          }
        }
      }
    }
    await _0x4dbfb4.sendMessage(_0x346059, {
      [_0x5e882a]: {
        'url': _0x37f972
      },
      'caption': _0x4c290c,
      'mimetype': _0x1ce4e,
      'fileName': _0x131716,
      ..._0x434bd2
    }, {
      'quoted': _0x208b6b,
      ..._0x434bd2
    });
    return fs.promises.unlink(_0x37f972);
  };
  _0x4dbfb4.sendText = (_0x1e1669, _0x540337, _0x1cf6a7 = '', _0x5d651c) => _0x4dbfb4.sendMessage(_0x1e1669, {
    'text': _0x540337,
    ..._0x5d651c
  }, {
    'quoted': _0x1cf6a7
  });
  _0x4dbfb4.serializeM = _0x58f0bd => smsg(_0x4dbfb4, _0x58f0bd, store);
  _0x4dbfb4.before = _0x32dcc4 => smsg(_0x4dbfb4, m, store);
  _0x4dbfb4.sendButtonText = (_0x50f763, _0x3130b7 = [], _0x1f35ae, _0x9b9613, _0x37a00b = '', _0x5a9087 = {}) => {
    let _0x5f5d94 = {
      'text': _0x1f35ae,
      'footer': _0x9b9613,
      'buttons': _0x3130b7,
      'headerType': 0x2,
      ..._0x5a9087
    };
    _0x4dbfb4.sendMessage(_0x50f763, _0x5f5d94, {
      'quoted': _0x37a00b,
      ..._0x5a9087
    });
  };
  _0x4dbfb4.sendKatalog = async (_0x1442e2, _0x3eaa9a = '', _0x59f2a8 = '', _0x5d74da, _0x5ad643 = {}) => {
    let _0x4a6d62 = await prepareWAMessageMedia({
      'image': _0x5d74da
    }, {
      'upload': _0x4dbfb4.waUploadToServer
    });
    const _0x2b2086 = generateWAMessageFromContent(_0x1442e2, {
      'productMessage': {
        'product': {
          'productImage': _0x4a6d62.imageMessage,
          'productId': "9999",
          'title': _0x3eaa9a,
          'description': _0x59f2a8,
          'currencyCode': "INR",
          'priceAmount1000': "100000",
          'url': '' + websitex,
          'productImageCount': 0x1,
          'salePriceAmount1000': '0'
        },
        'businessOwnerJid': ownernumber + "@s.whatsapp.net"
      }
    }, _0x5ad643);
    return _0x4dbfb4.relayMessage(_0x1442e2, _0x2b2086.message, {
      'messageId': _0x2b2086.key.id
    });
  };
  _0x4dbfb4.send5ButLoc = async (_0x17e200, _0x49a385 = '', _0x5e7540 = '', _0x3aab28, _0x573f9c = [], _0x4444a9 = {}) => {
    var _0x2ebdb2 = generateWAMessageFromContent(_0x17e200, proto.Message.fromObject({
      'templateMessage': {
        'hydratedTemplate': {
          'hydratedContentText': _0x49a385,
          'locationMessage': {
            'jpegThumbnail': _0x3aab28
          },
          'hydratedFooterText': _0x5e7540,
          'hydratedButtons': _0x573f9c
        }
      }
    }), _0x4444a9);
    _0x4dbfb4.relayMessage(_0x17e200, _0x2ebdb2.message, {
      'messageId': _0x2ebdb2.key.id
    });
  };
  global.API = (_0x2d86ae, _0x37482d = '/', _0x43fdf6 = {}, _0x417186) => (_0x2d86ae in global.APIs ? global.APIs[_0x2d86ae] : _0x2d86ae) + _0x37482d + (_0x43fdf6 || _0x417186 ? '?' + new URLSearchParams(Object.entries({
    ..._0x43fdf6,
    ...(_0x417186 ? {
      [_0x417186]: global.APIKeys[_0x2d86ae in global.APIs ? global.APIs[_0x2d86ae] : _0x2d86ae]
    } : {})
  })) : '');
  _0x4dbfb4.sendButImg = async (_0x462d80, _0x595989, _0x2e5dd3, _0x2b150e, _0x593e19) => {
    let _0x33205c = Buffer.isBuffer(_0x595989) ? _0x595989 : /^data:.*?\/.*?;base64,/i.test(_0x595989) ? Buffer.from(_0x595989.split`,`[0x1], "base64") : /^https?:\/\//.test(_0x595989) ? await await getBuffer(_0x595989) : fs.existsSync(_0x595989) ? fs.readFileSync(_0x595989) : Buffer.alloc(0x0);
    let _0x519389 = {
      'image': _0x33205c,
      'jpegThumbnail': _0x33205c,
      'caption': _0x2e5dd3,
      'fileLength': '1',
      'footer': _0x2b150e,
      'buttons': _0x593e19,
      'headerType': 0x4
    };
    _0x4dbfb4.sendMessage(_0x462d80, _0x519389, {
      'quoted': m
    });
  };
  _0x4dbfb4.sendFile = async (_0xb62507, _0x279577, _0x4a7ccf = '', _0x2087b4 = '', _0x443008, _0x2db707 = false, _0x9ec84d = {}) => {
    let _0x18041c = await _0x4dbfb4.getFile(_0x279577, true);
    let {
      res: _0x23e0e3,
      data: _0x56d731,
      filename: _0x257d7e
    } = _0x18041c;
    if (_0x23e0e3 && _0x23e0e3.status !== 0xc8 || _0x56d731.length <= 0x10000) {
      try {
        throw {
          'json': JSON.parse(_0x56d731.toString())
        };
      } catch (_0x405a47) {
        if (_0x405a47.json) {
          throw _0x405a47.json;
        }
      }
    }
    let _0x2b92b8 = {
      'filename': _0x4a7ccf
    };
    if (_0x443008) {
      _0x2b92b8.quoted = _0x443008;
    }
    if (!_0x18041c) {
      _0x9ec84d.asDocument = true;
    }
    let _0x93452e = '';
    let _0x348cbd = _0x18041c.mime;
    let _0x4b9f6f;
    if (/webp/.test(_0x18041c.mime) || /image/.test(_0x18041c.mime) && _0x9ec84d.asSticker) {
      _0x93452e = "sticker";
    } else {
      if (/image/.test(_0x18041c.mime) || /webp/.test(_0x18041c.mime) && _0x9ec84d.asImage) {
        _0x93452e = 'image';
      } else {
        if (/video/.test(_0x18041c.mime)) {
          _0x93452e = "video";
        } else {
          if (/audio/.test(_0x18041c.mime)) {
            _0x4b9f6f = await (_0x2db707 ? toPTT : toAudio)(_0x56d731, _0x18041c.ext);
            _0x56d731 = _0x4b9f6f.data;
            _0x257d7e = _0x4b9f6f.filename;
            _0x93452e = "audio";
            _0x348cbd = "audio/ogg; codecs=opus";
          } else {
            _0x93452e = "document";
          }
        }
      }
    }
    if (_0x9ec84d.asDocument) {
      _0x93452e = 'document';
    }
    delete _0x9ec84d.asSticker;
    delete _0x9ec84d.asLocation;
    delete _0x9ec84d.asVideo;
    delete _0x9ec84d.asDocument;
    delete _0x9ec84d.asImage;
    let _0x27f1fe = {
      ..._0x9ec84d,
      'caption': _0x2087b4,
      'ptt': _0x2db707,
      [_0x93452e]: {
        'url': _0x257d7e
      },
      'mimetype': _0x348cbd
    };
    let _0x553ffd;
    try {
      _0x553ffd = await _0x4dbfb4.sendMessage(_0xb62507, _0x27f1fe, {
        ..._0x2b92b8,
        ..._0x9ec84d
      });
    } catch (_0x6933b9) {
      _0x553ffd = null;
    } finally {
      if (!_0x553ffd) {
        _0x553ffd = await _0x4dbfb4.sendMessage(_0xb62507, {
          ..._0x27f1fe,
          [_0x93452e]: _0x56d731
        }, {
          ..._0x2b92b8,
          ..._0x9ec84d
        });
      }
      _0x56d731 = null;
      return _0x553ffd;
    }
  };
  _0x4dbfb4.ev.on("group-participants.update", async _0x4c7521 => {
    await (await import("./gc.js"))["default"](Lily, _0x4c7521);
  });
  _0x4dbfb4.sendFileUrl = async (_0x1ad430, _0x1bcdb2, _0x2d879f, _0x1473d4, _0x15ffa2 = {}) => {
    let _0x538fd9 = '';
    let _0x1b44c4 = await axios.head(_0x1bcdb2);
    _0x538fd9 = _0x1b44c4.headers["content-type"];
    if (_0x538fd9.split('/')[0x1] === "gif") {
      return _0x4dbfb4.sendMessage(_0x1ad430, {
        'video': await getBuffer(_0x1bcdb2),
        'caption': _0x2d879f,
        'gifPlayback': true,
        ..._0x15ffa2
      }, {
        'quoted': _0x1473d4,
        ..._0x15ffa2
      });
    }
    if (_0x538fd9 === "application/pdf") {
      return _0x4dbfb4.sendMessage(_0x1ad430, {
        'document': await getBuffer(_0x1bcdb2),
        'mimetype': "application/pdf",
        'caption': _0x2d879f,
        ..._0x15ffa2
      }, {
        'quoted': _0x1473d4,
        ..._0x15ffa2
      });
    }
    if (_0x538fd9.split('/')[0x0] === "image") {
      return _0x4dbfb4.sendMessage(_0x1ad430, {
        'image': await getBuffer(_0x1bcdb2),
        'caption': _0x2d879f,
        ..._0x15ffa2
      }, {
        'quoted': _0x1473d4,
        ..._0x15ffa2
      });
    }
    if (_0x538fd9.split('/')[0x0] === "video") {
      return _0x4dbfb4.sendMessage(_0x1ad430, {
        'video': await getBuffer(_0x1bcdb2),
        'caption': _0x2d879f,
        'mimetype': "video/mp4",
        ..._0x15ffa2
      }, {
        'quoted': _0x1473d4,
        ..._0x15ffa2
      });
    }
    if (_0x538fd9.split('/')[0x0] === "audio") {
      return _0x4dbfb4.sendMessage(_0x1ad430, {
        'audio': await getBuffer(_0x1bcdb2),
        'caption': _0x2d879f,
        'mimetype': "audio/mpeg",
        ..._0x15ffa2
      }, {
        'quoted': _0x1473d4,
        ..._0x15ffa2
      });
    }
  };
  _0x4dbfb4.sendPoll = (_0x2e7889, _0x394cf8 = '', _0x5d57ec = [], _0x327b91 = 0x1) => {
    return _0x4dbfb4.sendMessage(_0x2e7889, {
      'poll': {
        'name': _0x394cf8,
        'values': _0x5d57ec,
        'selectableCount': _0x327b91
      }
    });
  };
  return _0x4dbfb4;
}
theFontaine();
process.on("uncaughtException", function (_0xebb4e6) {
  console.log("Caught exception: ", _0xebb4e6);
});